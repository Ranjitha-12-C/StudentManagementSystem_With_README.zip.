import java.io.Serializable;
import java.util.Objects;

/**
 * Represents a student with basic personal and academic information.
 */
public class Student implements Serializable, Comparable<Student> {
    private int id;
    private String name;
    private int age;
    private String grade;
    private String address;

    /**
     * Constructs a new Student.
     * @param id Unique ID of the student.
     * @param name Full name of the student.
     * @param age Age of the student.
     * @param grade Grade or class of the student.
     * @param address Residential address of the student.
     */
    public Student(int id, String name, int age, String grade, String address) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.grade = grade;
        this.address = address;
    }

    // Getters and setters
    public int getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getGrade() { return grade; }
    public String getAddress() { return address; }
    public void setName(String name) { this.name = name; }
    public void setAge(int age) { this.age = age; }
    public void setGrade(String grade) { this.grade = grade; }
    public void setAddress(String address) { this.address = address; }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Age: " + age + ", Grade: " + grade + ", Address: " + address;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student)) return false;
        Student student = (Student) o;
        return id == student.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public int compareTo(Student other) {
        return Integer.compare(this.id, other.id);
    }
}
