# Student Management System

## Overview
This Java console application allows users to manage student data using Object-Oriented Programming principles and Java Collections. It supports CRUD operations with file persistence using serialization.

## Features
- Add, remove, update, and search for students by ID
- Store and retrieve student data from a `.dat` file
- Display sorted student records
- Validate inputs (e.g., unique ID, positive age)
- Uses ArrayList, HashMap, and TreeSet for efficient operations

## Technologies
- Java 8+
- Serialization (ObjectInputStream / ObjectOutputStream)
- Collections: ArrayList, HashMap, TreeSet

## How to Run
1. Compile all `.java` files:
   ```
   javac Student.java StudentManager.java StudentManagementSystem.java
   ```
2. Run the program:
   ```
   java StudentManagementSystem
   ```

## UML Diagram
See `uml_diagram.txt` for a simple UML structure.

## Author
Ranjitha Ranjitha
