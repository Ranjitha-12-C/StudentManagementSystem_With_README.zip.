import java.util.Scanner;

/**
 * Entry point for the Student Management System.
 * Provides a menu-driven interface.
 */
public class StudentManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentManager manager = new StudentManager();
        String filename = "students.dat";
        manager.loadFromFile(filename);

        while (true) {
            System.out.println("\n--- Student Management Menu ---");
            System.out.println("1. Add a new student");
            System.out.println("2. Remove a student by ID");
            System.out.println("3. Update student details by ID");
            System.out.println("4. Search for a student by ID");
            System.out.println("5. Display all students (sorted)");
            System.out.println("6. Exit and save data");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    try {
                        System.out.print("Enter ID: ");
                        int id = Integer.parseInt(scanner.nextLine());
                        System.out.print("Enter name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter age: ");
                        int age = Integer.parseInt(scanner.nextLine());
                        System.out.print("Enter grade: ");
                        String grade = scanner.nextLine();
                        System.out.print("Enter address: ");
                        String address = scanner.nextLine();

                        if (id <= 0 || age <= 0 || name.isEmpty() || address.isEmpty()) {
                            System.out.println("Invalid input. Please fill all fields correctly.");
                        } else {
                            manager.addStudent(new Student(id, name, age, grade, address));
                        }
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 2:
                    System.out.print("Enter ID to remove: ");
                    int idToRemove = Integer.parseInt(scanner.nextLine());
                    manager.removeStudent(idToRemove);
                    break;
                case 3:
                    System.out.print("Enter ID to update: ");
                    int idToUpdate = Integer.parseInt(scanner.nextLine());
                    System.out.print("Enter new name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new age: ");
                    int newAge = Integer.parseInt(scanner.nextLine());
                    System.out.print("Enter new grade: ");
                    String newGrade = scanner.nextLine();
                    System.out.print("Enter new address: ");
                    String newAddress = scanner.nextLine();
                    manager.updateStudent(idToUpdate, newName, newAge, newGrade, newAddress);
                    break;
                case 4:
                    System.out.print("Enter ID to search: ");
                    int idToSearch = Integer.parseInt(scanner.nextLine());
                    Student found = manager.searchStudent(idToSearch);
                    if (found != null) {
                        System.out.println(found);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;
                case 5:
                    manager.displayAllStudents();
                    break;
                case 6:
                    manager.saveToFile(filename);
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
