import java.io.*;
import java.util.*;

/**
 * Manages a collection of Student objects.
 * Provides CRUD operations, file I/O, and sorted display.
 */
public class StudentManager {
    private ArrayList<Student> students = new ArrayList<>();
    private HashMap<Integer, Student> studentMap = new HashMap<>();
    private TreeSet<Student> studentSet = new TreeSet<>();

    /**
     * Adds a new student if the ID is unique.
     * @param student The student to be added.
     */
    public void addStudent(Student student) {
        if (studentMap.containsKey(student.getId())) {
            System.out.println("Error: Student with this ID already exists.");
            return;
        }
        students.add(student);
        studentMap.put(student.getId(), student);
        studentSet.add(student);
        System.out.println("Student added successfully.");
    }

    /**
     * Removes a student by ID.
     * @param id The student's ID.
     */
    public void removeStudent(int id) {
        Student student = studentMap.remove(id);
        if (student != null) {
            students.remove(student);
            studentSet.remove(student);
            System.out.println("Student removed.");
        } else {
            System.out.println("Student not found.");
        }
    }

    /**
     * Updates details of a student by ID.
     * @param id The student's ID.
     * @param name New name.
     * @param age New age.
     * @param grade New grade.
     * @param address New address.
     */
    public void updateStudent(int id, String name, int age, String grade, String address) {
        Student student = studentMap.get(id);
        if (student != null) {
            studentSet.remove(student);
            student.setName(name);
            student.setAge(age);
            student.setGrade(grade);
            student.setAddress(address);
            studentSet.add(student);
            System.out.println("Student updated.");
        } else {
            System.out.println("Student not found.");
        }
    }

    /**
     * Searches for a student by ID.
     * @param id The student's ID.
     * @return The student object or null.
     */
    public Student searchStudent(int id) {
        return studentMap.get(id);
    }

    /**
     * Displays all students in sorted order.
     */
    public void displayAllStudents() {
        if (studentSet.isEmpty()) {
            System.out.println("No students found.");
        } else {
            for (Student s : studentSet) {
                System.out.println(s);
            }
        }
    }

    /**
     * Saves student data to a file.
     * @param filename File path.
     */
    public void saveToFile(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(students);
            System.out.println("Data saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    /**
     * Loads student data from a file.
     * @param filename File path.
     */
    public void loadFromFile(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            students = (ArrayList<Student>) ois.readObject();
            studentMap.clear();
            studentSet.clear();
            for (Student s : students) {
                studentMap.put(s.getId(), s);
                studentSet.add(s);
            }
            System.out.println("Data loaded successfully.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }
}
